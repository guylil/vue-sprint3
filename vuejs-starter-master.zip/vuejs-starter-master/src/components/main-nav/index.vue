<template src="./main-nav.component.html"></template>
<script src="./main-nav.component.js"></script>
<style src="./main-nav.component.scss" scoped lang="scss"></style>


