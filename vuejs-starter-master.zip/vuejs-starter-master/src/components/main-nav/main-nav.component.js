export default {
  name: 'main-nav'
}
