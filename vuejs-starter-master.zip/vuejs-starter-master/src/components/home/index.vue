<template src="./home.component.html"></template>
<script src="./home.component.js"></script>
<style src="./home.component.scss" scoped lang="scss"></style>


