export default  {
  data: () => {
    return {
      
    }
  }
}